const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// creating the schema and from schema we will create model
const placeSchema = new Schema({
    title: {
        type: String,required:true
    },
    description: {
        type: String,required:true
    },
    image: {
        type: String,required:true
    },
    address: {
        type: String,required:true
    },
    location: {
        lat: {
            type: Number,required:true
        },
        lng: {
            type: Number,required:true
        }
    },
    creator: {
        type: mongoose.Types.ObjectId,
        required: true,
        ref: 'User'
    }
})

module.exports = mongoose.model('Place',placeSchema);

/* A schema in Mongoose is a Blueprint that defines how data is organised 
within a mongodb collection. It specifies the fields

Model is the compiled version of schema. It servers as a constructor
that creates and interacts documents in mongodb collection. based on the defined schema

Models provide an interface for CRUD operations. */