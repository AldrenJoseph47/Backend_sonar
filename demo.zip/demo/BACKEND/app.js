// starting point of our application
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const placesroutes = require("./routes/places-routes");
const usersroutes = require("./routes/users-routes");
const { error } = require('console');
const HttpError = require("./model/http-error");
const mongoose = require("mongoose");


// to fetch the data from the body
app.use(bodyParser.json());

//
app.use((req,res,next)=>{
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers',
        'Origin, X-Requested-With, Content-type, Accept, Authorization');
        res.setHeader(
          "Access-Control-Allow-Methods",
          "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS,CONNECT,TRACE"
        );
    next();
 })


app.use('/api/places',placesroutes);  //creating a middleware
app.use('/api/users',usersroutes);  //creating a middleware

// middleware to handle unimplemented routes or paths
app.use((req, res, next) => {
    const error = new HttpError('Could not find this route. unimplemented route or path',404);
    throw error;
});

//error handling middleware

/*  this is a middleware function express applies on every incoming request
if a function is passed with four arguments express will treat this as special middleware function
or error handling function

this function will only executes if the  request is having error
attached to it*/
app.use((err, req, res, next) => {
    //if the response is sent it will pass to another middleware
    if(res.headerSent){         // if response has been sent it will not send again
        return next(err);
    }
    res.status(err.code || 500);
    res.json({message: err.message || 'An unknown error occurred!'});
});

mongoose.connect('mongodb+srv://aldrenjoseph:aldrenjoseph47@faith.y6xji.mongodb.net/faith?retryWrites=true&w=majority&appName=faith')

//to start the server
app.listen(4000);

//middleware
app.use(bodyParser.json());

