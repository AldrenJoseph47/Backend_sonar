const express = require('express');
const HttpError = require('../model/http-error');

// creating a router object to handle routes or path
const router = express.Router();

// import place controller 
const placesControllers = require('../controllers/place-controller')
const {check} = require('express-validator');
// Get places by place id
router.get('/:pid',placesControllers.getPlaceById);      // 
router.get('/user/:uid',placesControllers.getPlaceByCreator);
router.post('/',[check('title').not().isEmpty(),
    check('description').isLength({min:5}),
    check('address').not().isEmpty()],placesControllers.createPlace);
// update a patch
router.patch('/:pid',placesControllers.updatePlace);
// delete a patch
router.delete('/:pid',placesControllers.deletePlace);
module.exports = router;

