const express = require('express');
const httpError = require('../model/http-error');
const router = express.Router();
// import placecontroller
const userController = require('../controllers/user-controller');

router.get('/all',userController.getUsers);
router.post('/signup',userController.signup);
router.post('/login',userController.login);

module.exports = router