const express = require('express');
const httpError = require('../model/http-error');
const {v4 : uuidv4} = require('uuid');
const HttpError = require('../model/http-error');
const User = require('../model/User');

// var DUMMY_USERS = [
//     {
//         id:'u1',
//         name:'Arjun',
//         email:'arjun@gmail.com',
//         password:'12345'
//     }
// ]
const getUsers = async (req,res,next)=>{
    let users;
    try{
        users = await User.find({},'-password');// we dont want the password in the response
    }
    catch(err){
        const error = new HttpError('Fetching users failed, please try again later', 500);
        return next(error);
    }

    res.json({users:users})
}

const signup = async (req,res,next)=>{
    const {name, email, image, password} = req.body;
    // checking if user already exists
    let existingUser;
    try{
        existingUser = await User.findOne({email:email});    
    }
    catch(err){
        console.log(err);
        const error = new HttpError('signup failed, please try again later', 500);
        return next(error);
    }
    if(existingUser){
        const error = new HttpError('User already exists!!, please login', 422);
        return next(error);
    }
    const createdUser = new User({
        //id: uuidv4(),
        name:name,
        email:email,
        image : image,
        password:password
    })
    try{
        await createdUser.save();
    }
    catch(err){
        const error = new HttpError('signup failed, please try again later', 500);
        return next(error);
    }
    res.status(201).json({users:createdUser.toObject({getters:true})});
}

const login = async(req,res,next)=>{
    const {email, password} = req.body;
    let existingUser;
    try{
        existingUser = await User.findOne({email:email});    
    }
    catch(err){
        const error = new HttpError('login failed, please try again later', 500);
        return next(error);
    }
    if(!existingUser||existingUser.password !== password){
        const error = new HttpError('Invalid credentials', 401);
    }
    res.status(200).json({message:'Logged in successfully'})

}

exports.getUsers = getUsers
exports.signup = signup
exports.login = login