const express = require('express');
const HttpError = require('../model/http-error');
const {v4 : uuidv4} = require('uuid');
const {validationResult} = require('express-validator');
const Place = require('../model/place');
const User = require('../model/User');
const mongoose = require('mongoose');



//creating a dummy record to learn 
//POST PUT PATCH DELETE GET methods
var DUMMY_PLACES = [
    {
        id: 'p1',
        title: 'Empire State Building',
        description: 'One of the most famous sky scrapers in the world!',
        location: {
            lat: 40.7484405,
            lng: -73.9878584
        },
        address: '20W EAST New York',
        creator: 'u1'
    },
]

// Get places by place id

const getPlaceById = async (req, res, next) => {
    console.log("GET Request in place");    
    const placeId = req.params.pid;         // getting the place id from url
    // const place = DUMMY_PLACES.find(p => {      // finding the place by id in DUMMY_PLACES array
    //     return p.id === placeId;               // returning the place object
    //});
    let place;
    try {
        place = await Place.findById(placeId);
    } catch (err) {
        const error = new HttpError('something went wrong, could not find a place', 500);
        return next(error);
    }


    // if place is empty validation
    if (!place) {
        // // return res.status(404).json({ message: "could not find place with given creatorid" });
        // const error = new Error("could not find place with given placeid using the error handler");
        // error.code = 404;
        // throw error;
        throw new HttpError('could not find place with given placeid using the httperror',404)
    }
    //converting id to string: toObject({
    res.json({ place: place.toObject({ getters: true }) });

    //res.json({ place: place });         
};

// Task : create a router to get places by creatorID

const getPlaceByCreator = async (req, res, next) => {       // using '/' as a path to get
    console.log("GET Request in user");
    const userId = req.params.uid;              // getting the place id from url
    // const place = DUMMY_PLACES.find(p => {      // finding the place by id in DUMMY_PLACES array
    //     return p.creator === userId;               // returning the place object
    // });
    let place;
    try {
        place = await Place.find({creator: userId});
    } catch (err) {
        const error = new HttpError('something went wrong, could not find a place using creator', 500);
        return next(error);
    }
    // if place is empty validation
    if (!place) {
        // // return res.status(404).json({ message: "could not find place with given creatorid" });
        // const error = new Error("could not find place with given creatorid using the error handler");
        // error.code = 404;
        // throw error;
        throw new HttpError('could not find place with given placeid using the httperror',404)
    }
    res.json({ place: place });
};


// post method
const createPlace = async (req,res,next)=>{
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        console.log(errors);
        throw new HttpError('Invalid inputs passed, please check your data', 422);
    }
    const {title,description,location,address,creator} = req.body
    // const createPlace ={
    //     id: uuidv4(),
    //     title:title,
    //     description: description,
    //     location : location,
    //     address : address,
    //     creator: creator,
    // }
    // DUMMY_PLACES.push(createPlace);
    const createPlace = new Place ({
        title:title,
        description:description,
        location:location,
        address:address,
        image:'https://images.app.goo.gl/ko75o6rkehNG1F9q6',
        creator:creator
    })
    let user;
    try{
        user = await User.findById(creator);
    }catch(err){
        const error = new HttpError('Place Creation Failed',500);
        return next(error);
    }
    if(!user){
        const error = new HttpError('Could Not Find A User Id,Try Again',500);
        return next(error);
    }
    // after that
    try{
        const sess = await mongoose.startSession();
        sess.startTransaction();
        await createPlace.save({session:sess})
        user.places.push(createPlace);
        await user.save({session:sess})
        await sess.commitTransaction();
    }catch(err){
        const error = new HttpError('Add Place Failed',500);
        return next(error);
    }
    res.status(201).json({place:createPlace});
//     try{
//         await createPlace.save();
//     }catch(err){
//         const error = new HttpError('Place Creation Failed',500);
//         return next(error);
//     }
//     res.status(201).json({place:createPlace});
}
const updatePlace = async (req,res,next)=>{
    // iam gone update two place
    const {title,description} = req.body
    const placeId = req.params.pid;
    // const updatePlace = {...DUMMY_PLACES.find(p => p.id === placeId)};
    // const placeIndex = DUMMY_PLACES.findIndex(p => p.id === placeId);
    let place;
    try {
        place = await Place.updateMany({ _id: placeId }, { $set: { title: title, description: description } });
        place = await Place.findById(placeId);
    } catch (err) {
        console.log(err);
        const error = new HttpError('something went wrong, could not update place', 500);
        return next(error);
    }
    res.status(200).json({place:place})
};


const deletePlace = async (req,res,next)=>{
    const placeId = req.params.pid;
    let place;
    try{
        place = await Place.findById(placeId).populate('creator');
        console.log(place);
    }
    catch(err){
        const error = new HttpError('Deleting the place failed!',500);
        return next(error);
    }
    if(!place){
        const error = new HttpError('could not find the place for this id',404)
        return next(error);
    }
    try{
        const sess = await mongoose.startSession();
        sess.startTransaction()
        await place.deleteOne({session:sess});
        place.creator.places.pull(place)
        await place.creator.save({session:sess})
        await sess.commitTransaction()
    }catch(err){
        console.log(err)
        const error = new HttpError('Something went wrong, could not delete place',500)
        return next(error);
    }
    res.status(200).json({message:'Deleted Place...'})
}



exports.createPlace = createPlace;
exports.getPlaceById = getPlaceById;
exports.getPlaceByCreator = getPlaceByCreator;
exports.updatePlace = updatePlace;
exports.deletePlace = deletePlace;





