from django.urls import path
from .views import post_list, review_list, post_details_views, SignupAPIView, LoginAPIView

urlpatterns = [
    path('posts',post_list),
    path('reviews',review_list),
    path('posts/<slug:passed_id>',post_details_views),
    path('api/user/signup/', SignupAPIView.as_view(), name='user-signup'),
    path('api/user/login/', LoginAPIView.as_view(), name='user-Login'),

]