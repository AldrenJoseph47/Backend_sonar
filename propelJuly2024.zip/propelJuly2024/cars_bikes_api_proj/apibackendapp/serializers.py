from django.contrib.auth.hashers import make_password
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Category, Post, Reviews


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']


class CategorySerializer(serializers.ModelSerializer):
    class Meta:  # to add additional information
        model = Category  # which model to use
        fields = '__all__'  # which fields to use


class PostSerializer(serializers.ModelSerializer):
    post_title = serializers.CharField(max_length=100, min_length=10, allow_blank=False, trim_whitespace=True)
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())
    post_author_details = UserSerializer(source='post_author', read_only=True)  # new field created by user
    post_author = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())  # foreign key

    class Meta:
        model = Post
        fields = '__all__'

    def create(self, validated_data):
        validated_data['post_title'] = validated_data['post_title'].upper()
        return super().create(validated_data)


# class PostSerializer(serializers.ModelSerializer):
#     category = CategorySerializer()
#     post_author_username = serializers.SerializerMethodField()
#     class Meta:
#         model = Post
#         fields = 'all'
#
#     def get_post_author_username(self,obj):
#         return obj.post_author.username

class ReviewSerializer(serializers.ModelSerializer):
    # post = PostSerializer()
    post = serializers.PrimaryKeyRelatedField(queryset=Post.objects.all())
    post_details = PostSerializer(source='post', read_only=True)

    # review_author = UserSerializer()
    review_author = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    review_author_details = UserSerializer(source='review_author', read_only=True)

    class Meta:
        model = Reviews
        fields = '__all__'

    def create(self, validated_data):
        validated_data['post_title'] = validated_data['post_title'].upper
        return super().create(validated_data)


class SignupSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password']

    def create(self, validated_data):
        validated_data["password"] = (
            make_password(validated_data["password"]))
        return super(SignupSerializer, self).create(validated_data)


# serializer for login

class LoginSerializer(serializers.ModelSerializer):
    username = serializers.CharField()
    class Meta:
        model = User
        fields = ['username', 'password']
