import rest_framework.authtoken.models
from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.decorators import permission_classes, api_view
from rest_framework.parsers import JSONParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Post, Reviews
from .serializers import PostSerializer, ReviewSerializer, SignupSerializer, LoginSerializer
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.views import APIView
from rest_framework.authtoken.models import Token


# Create your views here.

# @csrf_exempt
@api_view(['GET', 'PUT', 'DELETE', 'POST'])
# @permission_classes((IsAuthenticated,))
def post_list(request):
    if request.method == "GET":
        post_list = Post.objects.all()  # datatype of post_list is Object
        post_list_serializer = PostSerializer(post_list, many=True)
        return JsonResponse(post_list_serializer.data, safe=False)


    elif request.method == "POST":
        # get the data from the default paramter:
        # request_data = JSONParser().parse(request)
        # request_data = request.data
        post_title = request.POST.get('post_title')
        post_description = request.POST.get('post_description')
        post_shortname = request.POST.get('post_shortname')
        post_author = request.POST.get('post_author')
        category = request.POST.get('category')
        post_image = request.FILES.get('post_image')
        request_data = {
            'post_title': post_title,
            'post_description': post_description,
            'post_shortname': post_shortname,
            'post_author': post_author,
            'category': category,
            'post_image': post_image
        }
        # using a serializer serialize the parsed json
        post_add_serializer = PostSerializer(data=request_data)
        # checking if serializer returns a valid data
        if post_add_serializer.is_valid():
            post_add_serializer.save()
            # send back the respond code and the copy of data added as JSON
            return JsonResponse(post_add_serializer.data, status=201)
        return JsonResponse(post_add_serializer.errors, status=400)


# @csrf_exempt
@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes((IsAuthenticated,))
def review_list(request):
    if request.method == "GET":
        review_list = Reviews.objects.all()  # datatype of post_list is Object
        review_list_serializer = ReviewSerializer(review_list, many=True)
        return JsonResponse(review_list_serializer.data, safe=False)

    elif request.method == "POST":
        request_data = JSONParser().parse(request)
        review_add_serializer = ReviewSerializer(data=request_data)
        if review_add_serializer.is_valid():
            review_add_serializer.save()
            return JsonResponse(review_add_serializer.data, status=201)
        return JsonResponse(review_add_serializer.errors, status=400)


# @csrf_exempt
@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes((IsAuthenticated,))
def post_details_views(request, passed_id):
    try:
        post_details = Post.objects.get(id=passed_id)
    except Post.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == "GET":
        post_details_serializer = PostSerializer(post_details)
        return JsonResponse(post_details_serializer.data, safe=False, status=200)

    elif request.method == "PUT":
        request_data = JSONParser().parse(request)
        post_update_serializer = PostSerializer(post_details, data=request_data)
        if post_update_serializer.is_valid():
            post_update_serializer.save()
            return JsonResponse(post_update_serializer.data, safe=False, status=200)  # Changed to 200
        return JsonResponse(post_update_serializer.errors, status=400)

    elif request.method == "DELETE":
        post_details.delete()
        return HttpResponse(status=204)


@api_view(['GET'])
# @permission_classes(IsAuthenticated, )
# @csrf_exempt
def search(request, passed_post):
    try:
        post_details = Post.objects.filter(post_shortname_icontains=passed_post) | Post.objects.filter(
            post_title_icontains=passed_post)
        if not post_details.exists():
            raise Exception("Not Found")
    except Exception as e:
        return JsonResponse({'error': 'No matching posts found'}, status=404)

    if request.method == "GET":
        post_detail_serializer = PostSerializer(post_details, many=True)
        return JsonResponse(post_detail_serializer.data, safe=False, status=200)


# implement logic for Sign Up class based view
class SignupAPIView(APIView):
    def post(self, request):
        serializer = SignupSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            res = {'status': status.HTTP_201_CREATED}
            return Response(res, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginAPIView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            username = serializer.validated_data['username']
            password = serializer.validated_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                token = Token.objects.get(user=user)
                response = {
                    'status': status.HTTP_200_OK,
                    'message': 'Success',
                    'data': {
                        'token': token.key
                    }
                }
                return Response(response, status=status.HTTP_200_OK)
            else:
                response = {
                    'status': status.HTTP_401_UNAUTHORIZED,
                    'message': 'Wrong Credentials'
                }
                return Response(response, status=status.HTTP_401_UNAUTHORIZED)

        response = {
            'status': status.HTTP_400_BAD_REQUEST,
            'message': 'Bad Request'
        }
        return Response(response, status=status.HTTP_400_BAD_REQUEST)
